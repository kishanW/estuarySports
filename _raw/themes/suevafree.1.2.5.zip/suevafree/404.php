<?php get_header(); ?>

<div class="container" style="position:relative">
	<div class="row" id="portfolio" >
		
		
        <div class="pin-article span12">

			<article class="article">
            
				<h1><?php _e( 'Not found','wip'); ?> </h1>
				<p><?php _e( 'Sorry, no posts matched your criteria','wip'); ?> </p>
 
			</article>

    	</div>
		
           
    </div>
</div>

<?php get_footer(); ?>